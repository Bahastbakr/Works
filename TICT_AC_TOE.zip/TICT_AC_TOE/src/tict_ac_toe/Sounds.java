package tict_ac_toe;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.swing.JOptionPane;
import sun.audio.AudioPlayer;
import sun.audio.AudioStream;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Best Technology
 */
public class Sounds {
    
    protected void playtabSound(){
        String s="C:\\Users\\Best Technology\\OneDrive\\Documents\\NetBeansProjects\\TICT_AC_TOE\\Music\\Click.wav";
        InputStream music;
        try{
            music=new FileInputStream(new File(s));
            AudioStream auidos=new AudioStream(music);
            AudioPlayer.player.start(auidos);
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null, "error");
        }
    }
     protected void playWinSound(){
        String s="C:\\Users\\Best Technology\\OneDrive\\Documents\\NetBeansProjects\\TICT_AC_TOE\\Music\\Tada.wav";
        InputStream music;
        try{
            music=new FileInputStream(new File(s));
            AudioStream auidos=new AudioStream(music);
            AudioPlayer.player.start(auidos);
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null, "error");
        }
    }
    
}
