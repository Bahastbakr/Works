/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tict_ac_toe;

import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author Best Technology
 */
public class Game extends Sounds{
    private String startgame="X";

    JButton jb1;
    JButton jb2;
    JButton jb3;
    JButton jb4;
    JButton jb5;
    JButton jb6;
    JButton jb7;
    JButton jb8;
    JButton jb9;
    
    JLabel jblPx;
    JLabel jplOP;
    JPanel jlBX;
    JPanel jlBO;
    private int xCount=0;
    private int oCount=0;
    
   

    public Game(JButton jb1, JButton jb2, JButton jb3,
            JButton jb4, JButton jb5, JButton jb6, JButton jb7,
            JButton jb8, JButton jb9, JLabel jblPx, JLabel jplOP ,JPanel jlBX,JPanel jlBO ) {
        this.jb1 = jb1;
        this.jb2 = jb2;
        this.jb3 = jb3;
        this.jb4 = jb4;
        this.jb5 = jb5;
        this.jb6 = jb6;
        this.jb7 = jb7;
        this.jb8 = jb8;
        this.jb9 = jb9;
        this.jblPx = jblPx;
        this.jplOP = jplOP;
         this.jlBX = jlBX;
        this.jlBO = jlBO;
    }

   
   
    private void choosePlayer(){
        if (startgame.equals("X")) {
            startgame="O";
            
               
        }
        else{
            startgame="X";
            
            
        }
        
    }
        protected void reset(){
        jb1.setText(null);
        jb2.setText(null);
        jb3.setText(null);
        jb4.setText(null);
        jb5.setText(null);
        jb6.setText(null);
        jb7.setText(null);
        jb8.setText(null);
        jb9.setText(null);


        jb1.setBackground(Color.LIGHT_GRAY);
        jb2.setBackground(Color.LIGHT_GRAY);
        jb3.setBackground(Color.LIGHT_GRAY);
        jb4.setBackground(Color.LIGHT_GRAY);
        jb5.setBackground(Color.LIGHT_GRAY);
        jb6.setBackground(Color.LIGHT_GRAY);
        jb7.setBackground(Color.LIGHT_GRAY);
        jb8.setBackground(Color.LIGHT_GRAY);
        jb9.setBackground(Color.LIGHT_GRAY);

    }
    
protected void gameScore(){
        jblPx.setText(String.valueOf(xCount));
        jplOP.setText(String.valueOf(oCount));
        if (xCount==10||oCount==10) {
            JOptionPane.showMessageDialog(null, "10 round finished game reseted ! ","Tic Tac Toe ",JOptionPane.INFORMATION_MESSAGE);
            reset();
            xCount=0;
            oCount=0;
            jplOP.setText(null);
            jblPx.setText(null);
        }

    }
    protected void wingame(){
        String b1=jb1.getText();
        String b2=jb2.getText();
        String b8=jb8.getText();
        
        
        String b3=jb3.getText();
        String b5=jb5.getText();
        String b7=jb7.getText();
        
        
        String b9=jb9.getText();
        String b6=jb6.getText();
        String b4=jb4.getText();
       
      //X POSIBILITIES------------------------------------------------------------------------------------------------------------------------------ 
     //FIRST ROW   // X-X-X
        if (b1 ==("X")&& b2==("X")&& b8==("X")) {
            
        
           xCount++;
           gameScore();
           jb1.setBackground(Color.yellow);
           jb2.setBackground(Color.yellow);
           jb8.setBackground(Color.yellow);
            playWinSound();
           JOptionPane.showMessageDialog(null,"Player X is winns ","Tic Tac Toe ",JOptionPane.INFORMATION_MESSAGE);
            reset();
            
       }
        

      //second  ROW   // X-X-X

        if (b3==("X")&& b5==("X")&& b7==("X")) {
            
           xCount++;
           gameScore();
           jb5.setBackground(Color.yellow);
           jb7.setBackground(Color.yellow);
           jb3.setBackground(Color.yellow);
            playWinSound();
           JOptionPane.showMessageDialog(null,"Player X is winns ","Tic Tac Toe ",JOptionPane.INFORMATION_MESSAGE);

           reset();

        }
        if (b9==("X")&& b6==("X")&& b4==("X")) {
            
           xCount++;
           gameScore();
           jb9.setBackground(Color.yellow);
           jb6.setBackground(Color.yellow);
           jb4.setBackground(Color.yellow);
            playWinSound();
           JOptionPane.showMessageDialog(null,"Player X is winns ","Tic Tac Toe ",JOptionPane.INFORMATION_MESSAGE);

           reset();

        }
        if (b1==("X")&& b3==("X")&& b4==("X")) {
            
           xCount++;
           gameScore();
           jb1.setBackground(Color.yellow);
           jb3.setBackground(Color.yellow);
           jb4.setBackground(Color.yellow);
                     playWinSound();
           JOptionPane.showMessageDialog(null,"Player X is winns ","Tic Tac Toe ",JOptionPane.INFORMATION_MESSAGE);

         
           reset();

        }
          if (b2==("X")&& b5==("X")&& b6==("X")) {
            
           xCount++;
           gameScore();
           jb2.setBackground(Color.yellow);
           jb5.setBackground(Color.yellow);
           jb6.setBackground(Color.yellow);
            playWinSound();
           JOptionPane.showMessageDialog(null,"Player X is winns ","Tic Tac Toe ",JOptionPane.INFORMATION_MESSAGE);

           reset();

        }
            if (b8==("X")&& b7==("X")&& b9==("X")) {
           xCount++;
           gameScore();
           jb8.setBackground(Color.yellow);
           jb7.setBackground(Color.yellow);
           jb9.setBackground(Color.yellow);
            playWinSound();

           JOptionPane.showMessageDialog(null,"Player X is winns ","Tic Tac Toe ",JOptionPane.INFORMATION_MESSAGE);

           reset();

        
            }
            
            //---------------------DIOGNISE
             if (b1==("X")&& b5==("X")&& b9==("X")) {
           xCount++;
           gameScore();
           jb1.setBackground(Color.yellow);
           jb5.setBackground(Color.yellow);
           jb9.setBackground(Color.yellow);
            playWinSound();

           JOptionPane.showMessageDialog(null,"Player X is winns ","Tic Tac Toe ",JOptionPane.INFORMATION_MESSAGE);

           reset();

        
            }
                 if (b8==("X")&& b5==("X")&& b4==("X")) {
           xCount++;
           gameScore();
           jb8.setBackground(Color.yellow);
           jb5.setBackground(Color.yellow);
           jb4.setBackground(Color.yellow);
            playWinSound();

           JOptionPane.showMessageDialog(null,"Player X is winns ","Tic Tac Toe ",JOptionPane.INFORMATION_MESSAGE);

           reset();

        
            }
        //---------------------DIOGNISE

        
        
//X POSIBILITIES------------------------------------------------------------------------------------------------------------------------------ 

        
//Y POSIBILITIES------------------------------------------------------------------------------------------------------------------------------ 
     //FIRST ROW   // YYY
        if (b1==("O")&& b2==("O")&& b8==("O")) {
            
        
           oCount++;
           gameScore();
           jb1.setBackground(Color.yellow);
           jb2.setBackground(Color.yellow);
           jb8.setBackground(Color.yellow);
            playWinSound();
           JOptionPane.showMessageDialog(null,"Player O is winns ","Tic Tac Toe ",JOptionPane.INFORMATION_MESSAGE);

            reset();
            
       }
        

      //second  ROW   // YYY

        if (b3==("O")&& b5==("O")&& b7==("O")) {
            
           oCount++;
           gameScore();
           jb5.setBackground(Color.yellow);
           jb7.setBackground(Color.yellow);
           jb3.setBackground(Color.yellow);
            playWinSound();
           JOptionPane.showMessageDialog(null,"Player O is winns ","Tic Tac Toe ",JOptionPane.INFORMATION_MESSAGE);
          
             reset();

        }
        if (b9==("O")&& b6==("O")&& b4==("O")) {
            
           oCount++;
           gameScore();
           jb9.setBackground(Color.yellow);
           jb6.setBackground(Color.yellow);
           jb4.setBackground(Color.yellow);
            playWinSound();

           JOptionPane.showMessageDialog(null,"Player O is winns ","Tic Tac Toe ",JOptionPane.INFORMATION_MESSAGE);
           reset();

        }
        if (b1==("O")&& b3==("O")&& b4==("O")) {
            
           oCount++;
           gameScore();
           jb1.setBackground(Color.yellow);
           jb3.setBackground(Color.yellow);
           jb4.setBackground(Color.yellow);
            playWinSound();

           JOptionPane.showMessageDialog(null,"Player O is winns ","Tic Tac Toe ",JOptionPane.INFORMATION_MESSAGE);

           reset();

        }
          if (b2==("O")&& b5==("O")&& b6==("O")) {
             oCount++;
           gameScore();
           jb2.setBackground(Color.yellow);
           jb5.setBackground(Color.yellow);
           jb6.setBackground(Color.yellow);
            playWinSound();
           JOptionPane.showMessageDialog(null,"Player O is winns ","Tic Tac Toe ",JOptionPane.INFORMATION_MESSAGE);

  reset();
          

        }
            if (b8==("O")&& b7==("O")&& b9==("O")) {
              oCount++;
           gameScore();
           jb8.setBackground(Color.yellow);
           jb7.setBackground(Color.yellow);
           jb9.setBackground(Color.yellow);
                       playWinSound();
         JOptionPane.showMessageDialog(null,"Player O is winns ","Tic Tac Toe ",JOptionPane.INFORMATION_MESSAGE);

  reset();
        
            }
            
            //---------------------DIOGNISE
             if (b1==("O")&& b5==("O")&& b9==("O")) {
              oCount++;
           gameScore();
           jb1.setBackground(Color.yellow);
           jb5.setBackground(Color.yellow);
           jb9.setBackground(Color.yellow);
                       playWinSound();
          JOptionPane.showMessageDialog(null,"Player O is winns ","Tic Tac Toe ",JOptionPane.INFORMATION_MESSAGE);


reset();

        
            }
                 if (b8==("O")&& b5==("O")&& b4==("O")) {
              oCount++;
           gameScore();
           jb8.setBackground(Color.yellow);
           jb5.setBackground(Color.yellow);
           jb4.setBackground(Color.yellow);
           playWinSound();
          
           JOptionPane.showMessageDialog(null,"Player O is winns ","Tic Tac Toe ",JOptionPane.INFORMATION_MESSAGE);
         
                reset();
                
            }
                 
               
                 
                   
                 
   
    }
    
    protected void buttonXorO(JButton button){
                 button.setText(startgame);
 
        if (startgame.equalsIgnoreCase("X")) {
            button.setForeground(Color.blue);
            jlBX.setBackground(Color.WHITE);
            jlBO.setBackground(Color.RED);
               
        }
        else{
           button.setForeground(Color.green);
           jlBX.setBackground(Color.RED);
            jlBO.setBackground(Color.WHITE);
        }
                choosePlayer();

    }
    
    
}
